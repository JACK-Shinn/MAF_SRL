t1 = clock;
addpath(genpath('functions'))
addpath(genpath('_multiview datasets'))

load('C:\Users\hsj\OneDrive\datasets\WebKB_cornell.mat')

% Y = truth;
listsize = length(Y);
v = length(X);   % the number of views
randindex = randperm(listsize);


nc = length(unique(Y));  % clusters
% Compute the similarities of all views
similarities = MultiviewSimilarity(X);
%save('similarities', 'similarities');
%load('similarities.mat')
% Compute the average similarity matrix
W = zeros(size(similarities{1}));
for ii = 1:v
    W = W + similarities{ii};
end
W = W./v;

sparsity = sum(sum(W<0.01)) / (size(W,1) * size (W,2))
save('C:\Users\xx\OneDrive\datasets\WebKB_cornellW', 'W');
t2 = clock;
Time = etime(t2,t1);